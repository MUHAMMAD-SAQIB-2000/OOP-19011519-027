package com.system.employee;

import java.util.List;

public class EmployeeDao {

	public EmployeeDao() {}
	
	public static Employee addEmployee(Employee employee) {
		return employee;
	}

	public static List<Employee> getAllEmployees(){
		return null;
	}
	
	public static List<Employee> getWorkingEmployee(){
		return null;
	}
	
	public static List<Employee> getEmployeeByStatus(String employeeStatus){
		return null;
	}
	
	public static List<Employee> getFiredOrLeftEmployees(){
		return null;
	}
	
	public static Employee updateEmployee(Employee employee){
		return employee;
	}
	
	public static Employee deleteEmployee(Integer Id){
		return employee;
	}

}
