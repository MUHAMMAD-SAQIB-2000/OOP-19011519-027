
public class Main {

	public static void main(String[] args) {
		myQueue q = new myQueue(5);
		/*q.enQueue(5);
		q.enQueue(4);
		q.enQueue(3);
		q.enQueue(1);
		q.enQueue(3);
		//q.enQueue(1);
		
		q.deQueue();
		q.show();*/
		
// Circular Queue
		q.circularEnQueue(10);
		q.circularEnQueue(20);
		q.circularEnQueue(30);
		q.circularEnQueue(40);
		q.circularEnQueue(50);
		//q.circularEnQueue(50);
		q.show();

	}

}
