

public class myQueue {
	private Node rear;
	private Node front;
	private int size;
	
	
public myQueue() {
	front=null;
	rear=null;
	size = 0;
}
public boolean isEmpty() {
	boolean response = false;
	if(size==0) {
		response = true;
	}
	return response;
}

public void enQueue(int data) {
	Node node = new Node(data);
	if(front==null) {
		rear = node;
		front = node;
		size++;
	}
	else {
		rear.setNext(node);
		rear = node ;
		size++;
	}
}

public Node deQueue() {
	
	Node response = null;
	if(front!=null) {
		if(front.getNext()!=null) {
			response = new Node(front.getData());
			front = front.getNext();
			size--;
		}
		else {
			response = new Node(front.getData());
			front = null;
			rear = null;
			size--;
		}
	}
	return response;
}

public void getAll() {
	if(front == null) {
		System.out.println("Empty ");
		return ;
	}
	Node response = front;
	while(response != null) {
		System.out.print(response.getData() + " " );
		response = response.getNext();
	}
	System.out.println();
}
public int getSize() {
	return size;
}
public Node peek() {
	Node  response = null;
	if(!isEmpty()) {
		response = new Node(front.getData());
	}
	return response;
}
}
