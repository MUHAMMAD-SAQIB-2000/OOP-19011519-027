


public class ATM {
	
	
	public static void main(String[] args) throws Exception {
		
		 
		OptionMenu optionmenu = new OptionMenu();
		
		optionmenu.login();
	}

}
