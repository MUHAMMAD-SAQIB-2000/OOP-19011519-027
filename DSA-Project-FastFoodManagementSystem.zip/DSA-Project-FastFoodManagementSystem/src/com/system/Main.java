package com.system;

import com.system.customer.Customer;

public class Main {

	public static void main(String[] args) {
		Customer c= new Customer();
		c.setCustomerBill(0);
	}

}
