package linkedlist.main;

public class MainApplication {

	public static void main(String[] args) {
//		LinkedList<Integer> list = new LinkedList<>();
//		list.add(8);
		LinkedListImp list = new LinkedListImp();
		list.values();
		list.add(45);
		list.add(8);
		list.values();
	}

}
