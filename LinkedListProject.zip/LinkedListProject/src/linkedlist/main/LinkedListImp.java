package linkedlist.main;

public class LinkedListImp {
	
	Node head;
	Node tail;
	Node current = head;
	int count;
	
	public LinkedListImp(Node newHead) {
		head = newHead;
		count = 1;
	}

	public LinkedListImp() {
		head = null;
		tail = null; 
	}
	
	public void add(int data) {
		Node node = new Node();
		node.data = data;
		if( head == null ) {
			head = node;
		}else {
			Node current = head;
			while(current.getNext()!= null) {//1,2,3, ,4
				current = current.getNext();
			}
			current.setNext(node);
		}
		count++;
	}
	
	public void values() {
		if( head == null ) {
			System.out.println("List is Empty");
			return ;
		}else {
			Node current = head;
			while(current != null) {//1,2,3
				System.out.println("Data is:" + current.getData());
				current = current.getNext();
			}
		}
	}

}
