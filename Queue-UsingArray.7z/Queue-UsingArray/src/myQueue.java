
public class myQueue {
      int[] queue ;
      int rear;
      int front;
      int size;
      int capacity;

public myQueue(int capacity) {
	this.capacity = capacity;
	 this.queue = new int[capacity];
}

      
public int size() {
	return size;
}

public boolean isEmpty() {
	boolean response = false;
	if(size==0) {
		response = true;
	}
	return response;
}
public boolean isFull(){
	return size == 5;
}

public void enQueue(int data){
	if(!isFull()){
	queue[rear] = data;
	rear=rear+1;
	size=size+1;	
}
	else
		System.out.println("Queue is full");
}
public int deQueue() {
	int data = queue[front];
	if(!isEmpty()) {
	front++;
	size--;
	}
   else
	System.out.println("Queue is Empty");
	return data;
}
public void show() {
	System.out.println("Elements :");
	for(int i=0 ; i<size ; i++) {
		System.out.print(queue[front+i] + " ");
	}
}
	
	/*
	 * Circular queue
	 */
public void circularEnQueue(int data) {
	if(size==capacity) {
		System.out.println("Queue is full,Can't insert.");
		return;
	}
	rear =(rear+1)%capacity;
	queue[rear] = data;
	size++;
	System.out.println(data + "\tenqueued into queue.");
	System.out.println("After enqueued Rear is " + rear);	
}

public void circularDeQueue() {
	if(size==0) {
		System.out.println("Queue is empty");
		return;
	}
	int data = queue[front];
	front = (front+1)%capacity;
	size--;
	System.out.println(data + "\tdequeued from queue.");
	System.out.println("After enqueued front is " + front);	
}

public int front() {
	if(isEmpty()) {
		return Integer.MIN_VALUE;
	}
	return queue[front];
}

public int rear() {
	if(isEmpty()) {
		return Integer.MAX_VALUE;
	}
	return queue[rear];
}






}