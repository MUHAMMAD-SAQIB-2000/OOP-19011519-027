import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Scanner;

public class OptionMenu extends Account {
	
	Scanner MenuInput = new Scanner(System.in);
	DecimalFormat moneyformat= new DecimalFormat("$###,##0.00");
	HashMap<Integer , Integer> Info = new HashMap<Integer , Integer>();
	
	private int select;
	
	/*
	 * Login Information ,Customer number and Pin number
	 */
	
	public void login() {
		
		int x=1;
		do {
			try {
			Info.put(111111, 222);
			Info.put(333333, 444);
			System.out.println("===========================================");
			System.out.println( " \t\t Welcome to ATM."           );
			System.out.println("==========================================="); 
			System.out.println("Enter your customer number:");
			setCustomerNumber(MenuInput.nextInt());
			System.out.println("Enter your PinNumber:");
			setPinNumber(MenuInput.nextInt());
			}catch(Exception e) {
				System.out.println("Invalid Input..." +"Enter Numbers Only");
				x=2;
			}
			for(Entry<Integer, Integer> data: Info.entrySet()) {
				
				if(data.getKey()==getCustomerNumber() && data.getValue()==getPinNumber()) {
					getAccountType();
				}	
				else {
					System.out.println("wrong customer number or pin number." + "\n");
					}
			}
			
		}while(x==1);
		}
	
	  
	/*
	 * Account Type with selection
	 */

	public void getAccountType( ) {
		System.out.println("Select the Account you want to access:");
		System.out.println("1.  Checking Account.");
		System.out.println("2.  Saving Account");
		System.out.println("3.  Exit");
		System.out.println("Choice:");
		select = MenuInput.nextInt();
		
		switch(select) {
		case 1:
		  getChecking();
		  break;
		  
		case 2:
			  getSaving();
			  break;
			  
		case 3:
			System.out.println("\n" + " Thanks for using this ATM,bye." +"\n");
			  break;
			  
		default :
			System.out.println( "\n" +"Invalid Choice...!!!" + "\n");
			  break;
		}
		
	}
	/*
	 * Checking Account with Selection
	 */
	
	public void getChecking() {
		System.out.println("Checking Account:");
		System.out.println("1.  Current Balance");
		System.out.println("2.  WithDraw Funds");
		System.out.println("3.  Deposit Funds");
		System.out.println("4.  Exit");
		System.out.println("Choice:");
		
		select = MenuInput.nextInt();
		
		switch(select) {
		case 1:
			System.out.println("Checking Account Balance :" + moneyformat.format(getCheckingBalance()));
		     break;
		case 2:
			getCheckingWithdrawFunds();
			getAccountType();
			break;
		case 3:
			getCheckingDepositFunds();
			getAccountType();
			break;
		case 4:
			System.out.println("Thanks for using this ATM,bye.");
			getAccountType();
			break;
	    default :
			System.out.println(   "\n"  + "Invalid Choice...!!!" + "\n");
			getAccountType();
			break;
		}
	}
	
	/*
	 * Saving Account with selection
	 */
	
	public void getSaving() {
		
		System.out.println("Saving Account:");
		System.out.println("1.  Current Balance");
		System.out.println("2.  WithDraw Funds");
		System.out.println("3.  Deposite Funds");
		System.out.println("4.  Exit");
		System.out.println("Choice:");
		
		select = MenuInput.nextInt();
		
		switch(select) {
		case 1:
			System.out.println("Saving Account Balance :" + moneyformat.format(getCheckingBalance()));
			getAccountType();
		     break;
		case 2:
			getSavingWithdrawFunds();
			getAccountType();
			break;
		case 3:
			getSavingDepositFunds();
			getAccountType();
			break;
		case 4:
			System.out.println("Thanks for using this ATM,bye.");
			getAccountType();
			break;
	    default :
			System.out.println(   "\n"  + "Invalid Choice...!!!" + "\n");
			getAccountType();
			break;
		
		
	}
	
	}	
	
}
