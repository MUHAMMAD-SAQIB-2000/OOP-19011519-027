package com.assignment.linkedlist;

public class MainClass {
	
	public static void main(String[] args) {
		
		LinkedListClass list = new LinkedListClass();
		LinkedListClass list2 = new LinkedListClass();
		int count = list.getCount();
		System.out.println(count);
		list.add(1249);
		list.add(12);
		System.out.println("Enter limit");
		int limit = 2;
		if(count==limit) {
			System.out.println("You connot add more data");
		}else {
			list.add(1249);
			list.getAll();
			System.out.println("Data added");
		}
		list.add(1249);
		list.add(12);
		list.getAll();
		list.circularListDisplay();
		list.arithemticAdd();
		list2.add(36);
		list2.add(36);
		list2.add(36);
		list2.getAll();
		LinkedListClass.mergeLinkedList(list, list2);
//		list.delAtStart();
//		list.add(14);list.add(16);list.add(18);list.add(20);
//		list.getAll();
//		int get = list.get(3);
//		System.out.println("GEt output: " + get);
//		list.insertAtIndex(2, 195);
//		list.getAll();
//		list.addAtStart(45);
//		list.add(120);
//		list.add(120);
//		list.add(120);
//		list.getAll();
//		list.delAtEnd();
//		list.getAll();
//		list.delAtIndex(2);
//		list.getAll();
//		list.valueUpdateAtIndex(0, 55765);
//		list.valueUpdateAtIndex(2, 576);
//		list.getAll();
//		list.valueUpdateByData(12 , 3636);
//		list.getAll();
//		list.searchByData(120);
		
	}

}
