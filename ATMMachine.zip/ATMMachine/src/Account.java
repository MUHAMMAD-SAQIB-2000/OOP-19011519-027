import java.text.DecimalFormat;
import java.util.Scanner;

public class Account {
	
	DecimalFormat moneyformat= new DecimalFormat("$###,##0.00");
	Scanner input = new Scanner(System.in);
	
	
	private int CustomerNumber;
	private int PinNumber;
	private double CheckingBalance=0;
	private double savingBalance =0;
	
    /*
     * Get and Set the customer number
     */
	
	public int getCustomerNumber() {
		return CustomerNumber;
	}
	public void setCustomerNumber(int customerNumber) {
		CustomerNumber = customerNumber;
	}
	
	/*
	 * Get and Set the Pin number
	 */
	public int getPinNumber() {
		return PinNumber;
	}
	public void setPinNumber(int pinNumber) {
		PinNumber = pinNumber;
	}
	
	/*
	 * Get and Set the Checking Accecount Balan
	 */
	public double getCheckingBalance() {
		return CheckingBalance;
	}
	public void setCheckingBalance(double checkingBalance) {
		CheckingBalance = checkingBalance;
	}
	
	/*
	 *  Get and Set the Saving Accecount Balan
	 */
	public double getSavingBalance() {
		return savingBalance;
	}
	public void setSavingBalance(double savingBalance) {
		this.savingBalance = savingBalance;
	}
	
	/*
	 * Calculate Checking Account Balance after Deposit
	 */
	
	public double CheckingDeposit(double amount) {
		
		return CheckingBalance =( CheckingBalance + amount);
	}
	
	/*
	 *  Calculate Saving Account Balance after Deposit
	 */
	
	public double SavingDeposit(double amount) {
		
		return savingBalance =( savingBalance + amount);
	}
	
	/*
	 * Calculate Checking Account Balance after withdraw
	 */
	
	public double CheckingWithDraw(double amount) {
		return CheckingBalance =( CheckingBalance - amount);
	}
	
	/*
	 * Calculate Saving Account Balance after withdraw
	 */
	
	public double SavingWithDraw(double amount) {
		return savingBalance =( savingBalance - amount);
	}
	
	/*
	 * Customer's Checking Account withdraw input
	 */
	
	public void getCheckingWithdrawFunds() {
		System.out.println("Checking Account Balance :" + moneyformat.format(CheckingBalance));
		System.out.println("Amount you want to withdraw: ");
		double amount = input.nextDouble();
		if(( CheckingBalance - amount) >=0) {
			
			CheckingWithDraw(amount);
			System.out.println("New Checking Account Balance :" + moneyformat.format(CheckingBalance));
			
		}
		else {
			System.out.println("Balance cannot be negative.");
		}
	}
	
	/*
	 *   Customer's Checking Account deposit input
	 */
	
	
	public void getCheckingDepositFunds() {
		System.out.println("Checking Account Balance :" + moneyformat.format(CheckingBalance));
		System.out.println("Amount you want to deposit: ");
		double amount = input.nextDouble();
		if(( CheckingBalance + amount) >=0) {
			
			CheckingDeposit(amount);
			System.out.println("New Checking Account Balance :" + moneyformat.format(CheckingBalance));
			
		}
		else {
			System.out.println("Balance cannot be negative.");
		}
		
	}
	
	/*
	 *  Customer's Saving Account deposit input
	 */
	

	public void getSavingDepositFunds() {
		System.out.println("Saving Account Balance :" + moneyformat.format(savingBalance));
		System.out.println("Amount you want to deposit: ");
		double amount = input.nextDouble();
		
		if(( savingBalance + amount) >=0) {
			
			SavingDeposit(amount);
			System.out.println("New Saving Account Balance :" + moneyformat.format(savingBalance));
			
		}
		else {
			System.out.println("Balance cannot be negative.");
		}
	}
	
	/*
	 *  Customer's Saving Account withdraw input
	 */
	public void getSavingWithdrawFunds() {
		System.out.println("Saving Account Balance :" + moneyformat.format(savingBalance));
		System.out.println("Amount you want to withdraw: ");
		double amount = input.nextDouble();
		if(( savingBalance - amount) >=0) {
			
			SavingDeposit(amount);
			System.out.println("New Saving Account Balance :" + moneyformat.format(savingBalance));
			
		}
		else {
			System.out.println("Balance cannot be negative.");
		}
	}
}
