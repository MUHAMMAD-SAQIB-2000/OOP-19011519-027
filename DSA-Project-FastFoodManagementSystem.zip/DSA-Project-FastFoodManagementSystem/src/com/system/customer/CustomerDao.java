package com.system.customer;

import java.util.List;

public class CustomerDao {

	public CustomerDao() {
	}
	
	public static Customer addRecord(Customer customer) {
		return customer;
	}

	public static List<Customer> getAllHistory(){
		return null;
	}
	
	public static List<Customer> getTodayHistory(){
		return null;
	}
	
	public static List<Customer> getPresentMonthsHistory(){
		return null;
	}
	
	public static List<Customer> get30DaysHistory(){
		return null;
	}
	
	public static Customer addMemberShipCustomer(Customer customer){
		return customer;
	}
	
	public static List<Customer> getMemberShipCustomer(){
		return null;
	}
	
}
