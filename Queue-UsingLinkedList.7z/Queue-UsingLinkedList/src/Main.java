
public class Main {
     
	public static void main(String[] args) {
		myQueue q = new myQueue();
		q.enQueue(10);
		q.enQueue(20);
		q.enQueue(30);
		q.enQueue(40);
		/*System.out.println(q.getSize());
		System.out.println(q.peek().getData()+ ": front");
		System.out.println(q.deQueue().getData() + " deleted from queue.");
		System.out.println(q.deQueue().getData() + " deleted from queue.");*/
		q.getAll();
	}
}
